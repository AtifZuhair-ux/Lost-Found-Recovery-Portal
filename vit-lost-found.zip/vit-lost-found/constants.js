const range = (a, b) => Array.from({ length: b.charCodeAt(0) - a.charCodeAt(0) + 1 }, (_, i) => String.fromCharCode(a.charCodeAt(0) + i));
const VENUE_GROUPS = {
  'Academic Blocks': ['SJT', 'TT', 'PRP', 'SMV', 'MB', 'GDN', 'CDMM'],
  "Men's Hostels": range('A', 'T').map(c => `MH-${c}`),
  "Ladies' Hostels": range('A', 'J').map(c => `LH-${c}`),
  'Food Courts': ['Gazebo', 'Food Mall', 'DC'],
  Other: ['Central Library', 'Sports Complex']
};
const VENUES = Object.values(VENUE_GROUPS).flat();
const CATEGORIES = ['ID Cards', 'Room Keys', 'Calculators', 'Lab Equipment', 'Earphones', 'Wallets'];
const CHECKPOINTS = [
  'SJT Ground Floor Reception', 'TT Main Lobby', 'Central Library Security Desk',
  'Gazebo Entrance', 'Food Mall Entrance', 'Sports Complex Reception',
  'Main Gate Security Desk', 'Hostel Block Warden Desk'
];
module.exports = { VENUE_GROUPS, VENUES, CATEGORIES, CHECKPOINTS };
