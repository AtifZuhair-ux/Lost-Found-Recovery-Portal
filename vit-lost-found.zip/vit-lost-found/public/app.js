const app = document.getElementById('app'), nav = document.getElementById('nav');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const when = s => new Date(s.replace(' ', 'T') + 'Z').toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
let me = null, meta = null, timer = null;

async function api(url, method = 'GET', body) {
  let r;
  try { r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body && JSON.stringify(body) }); }
  catch { throw Object.assign(new Error('Cannot reach the server. Check your connection.'), {}); }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || 'Something went wrong.'), { fields: d.fields, status: r.status });
  return d;
}
function toast(m, bad) { const t = document.getElementById('toast'); t.textContent = m; t.className = 'show' + (bad ? ' bad' : ''); setTimeout(() => t.className = '', 2600); }
const skel = n => '<div class="skel"></div>'.repeat(n);
const opts = (list, sel) => list.map(v => `<option ${v === sel ? 'selected' : ''}>${esc(v)}</option>`).join('');
const venueOpts = () => Object.entries(meta.venueGroups).map(([g, v]) => `<optgroup label="${esc(g)}">${opts(v)}</optgroup>`).join('');

// Generic form handler: validation errors, loading state, success callback
function bindForm(form, submitLabel, action) {
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = form.querySelector('button[type=submit]'), top = form.querySelector('.formerr');
    form.querySelectorAll('[data-err]').forEach(x => x.textContent = ''); top.innerHTML = '';
    btn.disabled = true; btn.textContent = 'Submitting…';
    try { await action(Object.fromEntries(new FormData(form))); }
    catch (err) {
      if (err.status === 401) return location.hash = '#/login';
      top.innerHTML = `<div class="banner err">${esc(err.message)}</div>`;
      Object.entries(err.fields || {}).forEach(([k, v]) => { const el = form.querySelector(`[data-err=${k}]`); if (el) el.textContent = v; });
      btn.disabled = false; btn.textContent = submitLabel;
    }
  });
}
const fld = (name, label, html) => `<label>${label}</label>${html}<div class="err" data-err="${name}"></div>`;

function renderNav() {
  nav.innerHTML = me
    ? `<a href="#/feed/lost">Feed</a><a href="#/post">Post item</a><a href="#/dashboard">Dashboard</a><a href="#" id="out">Logout (${esc(me.name.split(' ')[0])})</a>`
    : `<a href="#/feed/lost">Feed</a><a href="#/login">Log in</a><a href="#/register">Sign up</a>`;
  const o = document.getElementById('out');
  if (o) o.onclick = async e => { e.preventDefault(); await api('/api/auth/logout', 'POST'); me = null; renderNav(); location.hash = '#/login'; };
}

// ---------- views ----------
async function feed(type) {
  const qs = new URLSearchParams(sessionStorage.filters || '');
  app.innerHTML = `<div class="tabs"><a href="#/feed/lost" class="${type === 'lost' ? 'on' : ''}">🔍 Lost</a><a href="#/feed/found" class="${type === 'found' ? 'on' : ''}">📦 Found</a></div>
  <div class="filters"><input id="q" placeholder="Search…" value="${esc(qs.get('q'))}">
  <select id="cat"><option value="">All categories</option>${opts(meta.categories, qs.get('category'))}</select>
  <select id="ven"><option value="">All campus venues</option>${venueOpts()}</select></div><div id="list">${skel(3)}</div>`;
  document.getElementById('ven').value = qs.get('venue') || '';
  const load = async () => {
    const p = new URLSearchParams({ type, q: q.value, category: cat.value, venue: ven.value });
    sessionStorage.filters = p.toString();
    list.innerHTML = skel(3);
    try {
      const items = await api('/api/items?' + p);
      list.innerHTML = items.length ? items.map(i => `<a class="card" style="display:block;color:inherit;text-decoration:none" href="#/item/${i.id}">
        <h3>${esc(i.title)}</h3><span class="tag">${esc(i.category)}</span><span class="tag">📍 ${esc(i.venue)}</span>
        <p>${esc(i.description)}</p><span class="mut">${when(i.created_at)}</span></a>`).join('')
        : `<div class="empty">No active ${type} items match your filters.<br><a href="#/post">Post one</a></div>`;
    } catch (e) { list.innerHTML = `<div class="banner err">${esc(e.message)}</div>`; }
  };
  let t; q.oninput = () => { clearTimeout(t); t = setTimeout(load, 300); };
  cat.onchange = ven.onchange = load; load();
}

function postForm() {
  if (!me) return location.hash = '#/login';
  app.innerHTML = `<form class="card" novalidate><h2>Post an item</h2><div class="formerr"></div>
  ${fld('type', 'I…', `<select name="type"><option value="lost">Lost something</option><option value="found">Found something</option></select>`)}
  ${fld('title', 'Title', '<input name="title" maxlength="80" placeholder="e.g. Blue student ID card">')}
  ${fld('category', 'Category', `<select name="category">${opts(meta.categories)}</select>`)}
  ${fld('venue', 'Campus location', `<select name="venue">${venueOpts()}</select>`)}
  ${fld('description', 'Public description', '<textarea name="description" maxlength="500" placeholder="Keep identifying details (name, number) OUT of this text."></textarea>')}
  ${fld('challenge', 'Verification question', '<input name="challenge" maxlength="200" placeholder="Finder: “What name/branch is on the ID?”  Owner: “Where did you find it?”">')}
  <p class="mut">Your identity stays hidden. Only the question is public; answers are reviewed privately by you.</p>
  <button type="submit">Publish</button></form>`;
  const f = app.querySelector('form');
  bindForm(f, 'Publish', async d => { const r = await api('/api/items', 'POST', d); toast('Listing published'); location.hash = '#/item/' + r.id; });
}

async function itemView(id) {
  app.innerHTML = skel(2);
  try {
    const it = await api('/api/items/' + id);
    let action = '';
    if (it.status === 'resolved') action = '<div class="banner good">✅ This item has been resolved.</div>';
    else if (it.isPoster) action = `<div class="row"><a class="btn" href="#/dashboard">Review requests</a><button class="sec" id="res">Mark resolved</button></div>`;
    else if (!me) action = '<a class="btn" href="#/login">Log in to submit a claim</a>';
    else if (it.myClaim) action = `<div class="banner good">Your request is <b>${it.myClaim.status}</b>.</div>` +
      (it.myClaim.status === 'approved' ? `<a class="btn" href="#/thread/${it.myClaim.id}">Open handoff chat</a>` : '');
    else action = `<form novalidate><h3>Claim verification request</h3><div class="formerr"></div>
      <p><b>Question:</b> ${esc(it.challenge)}</p>${fld('answer', 'Your answer', '<textarea name="answer" maxlength="300"></textarea>')}<button type="submit">Submit request</button></form>`;
    app.innerHTML = `<div class="card"><a href="#/feed/${it.type}">← Back</a><h2>${esc(it.title)}</h2>
      <span class="tag">${it.type.toUpperCase()}</span><span class="tag">${esc(it.category)}</span><span class="tag">📍 ${esc(it.venue)}</span>
      <p>${esc(it.description)}</p><p class="mut">Posted by ${esc(it.postedBy)} · ${when(it.created_at)}</p></div><div class="card">${action}</div>`;
    const f = app.querySelector('form');
    if (f) bindForm(f, 'Submit request', async d => { await api(`/api/items/${id}/claims`, 'POST', d); toast('Request sent'); itemView(id); });
    const r = document.getElementById('res'); if (r) r.onclick = () => resolve(id, () => itemView(id));
  } catch (e) { app.innerHTML = `<div class="banner err">${esc(e.message)}</div>`; }
}
async function resolve(id, done) {
  if (!confirm('Mark this item as returned/resolved? It will leave the active boards.')) return;
  try { await api(`/api/items/${id}/resolve`, 'POST'); toast('Marked resolved'); done(); } catch (e) { toast(e.message, true); }
}

async function dashboard() {
  if (!me) return location.hash = '#/login';
  app.innerHTML = skel(3);
  try {
    const d = await api('/api/dashboard');
    app.innerHTML = `<h2>My listings</h2>` + (d.listings.length ? d.listings.map(l => `<div class="card">
      <h3>${esc(l.title)} <span class="tag">${l.type}</span><span class="tag">${l.status}</span></h3><div class="mut">Your question: ${esc(l.challenge)}</div>
      ${l.claims.length ? l.claims.map(c => `<div class="card" style="background:#f8f9fc"><b>${esc(c.alias)}</b> <span class="tag ${c.status}">${c.status}</span>
        <p>“${esc(c.answer)}”</p>${c.status === 'pending' && l.status === 'active' ? `<div class="row"><button class="ok" data-d="approved" data-c="${c.id}">Approve</button><button class="bad" data-d="rejected" data-c="${c.id}">Reject</button></div>` : ''}
        ${c.status === 'approved' ? `<a class="btn" href="#/thread/${c.id}">Open chat</a>` : ''}</div>`).join('') : '<p class="mut">No requests yet.</p>'}
      ${l.status === 'active' ? `<button class="sec" data-r="${l.id}">Mark resolved</button>` : ''}</div>`).join('')
      : '<div class="empty">You have not posted anything yet.</div>') +
      `<h2>My requests</h2>` + (d.myClaims.length ? d.myClaims.map(c => `<div class="card"><a href="#/item/${c.id}"><b>${esc(c.title)}</b></a>
      <span class="tag ${c.claim_status}">${c.claim_status}</span> ${c.claim_status === 'approved' ? `<a class="btn" href="#/thread/${c.claim_id}">Open chat</a>` : ''}</div>`).join('')
      : '<div class="empty">You have not claimed anything.</div>');
    app.querySelectorAll('[data-d]').forEach(b => b.onclick = async () => {
      b.disabled = true; b.textContent = '…';
      try { await api(`/api/claims/${b.dataset.c}/decision`, 'POST', { decision: b.dataset.d }); toast('Decision saved'); dashboard(); }
      catch (e) { toast(e.message, true); dashboard(); }
    });
    app.querySelectorAll('[data-r]').forEach(b => b.onclick = () => resolve(b.dataset.r, dashboard));
  } catch (e) { app.innerHTML = `<div class="banner err">${esc(e.message)}</div>`; }
}

async function thread(id) {
  if (!me) return location.hash = '#/login';
  const draw = async (first) => {
    if (!location.hash.startsWith('#/thread/')) return clearInterval(timer);
    try {
      const t = await api(`/api/claims/${id}/thread`);
      const keep = document.getElementById('body')?.value || '';
      app.innerHTML = `<div class="card"><a href="#/dashboard">← Dashboard</a><h2>${esc(t.title)}</h2>
        <div class="mut">Identities stay hidden. Share contact details only if you choose to.</div>
        ${t.resolved ? '<div class="banner good">✅ Resolved — chat closed.</div>' : `<div class="row" style="margin:.6rem 0"><select id="cp"><option value="">Propose a meetup checkpoint…</option>${opts(meta.checkpoints, t.checkpoint)}</select><button class="sec" id="setcp">Propose</button></div>`}
        <div class="chat" id="chat">${t.messages.map(m => `<div class="msg ${m.system ? 'sys' : m.mine ? 'me' : ''}">${m.system ? '' : `<small>${esc(m.from)} · ${when(m.created_at)}</small>`}${esc(m.body)}</div>`).join('')}</div>
        ${t.resolved ? '' : `<form novalidate><div class="formerr"></div><div class="row"><input id="body" name="body" maxlength="500" placeholder="Type a message" style="flex:1"><button type="submit">Send</button></div></form><br><button class="ok" id="done">Item returned — mark resolved</button>`}</div>`;
      const chat = document.getElementById('chat'); chat.scrollTop = chat.scrollHeight;
      if (t.resolved) return clearInterval(timer);
      document.getElementById('body').value = keep;
      if (!first && keep) document.getElementById('body').focus();
      bindForm(app.querySelector('form'), 'Send', async d => { await api(`/api/claims/${id}/messages`, 'POST', d); draw(); });
      document.getElementById('setcp').onclick = async () => {
        try { await api(`/api/claims/${id}/checkpoint`, 'POST', { checkpoint: cp.value }); toast('Checkpoint proposed'); draw(); } catch (e) { toast(e.message, true); }
      };
      document.getElementById('done').onclick = () => resolve(t.itemId, () => draw());
    } catch (e) { clearInterval(timer); app.innerHTML = `<div class="banner err">${esc(e.message)}</div>`; }
  };
  app.innerHTML = skel(2); await draw(true);
  clearInterval(timer); timer = setInterval(() => { if (!document.activeElement || document.activeElement.id !== 'body' || !document.activeElement.value) draw(); }, 6000);
}

function authForm(kind) {
  const reg = kind === 'register';
  app.innerHTML = `<form class="card" novalidate style="max-width:420px;margin:auto"><h2>${reg ? 'Create account' : 'Log in'}</h2><div class="formerr"></div>
  ${fld('reg_no', 'Registration number', '<input name="reg_no" placeholder="25BIT0123" autocomplete="username">')}
  ${reg ? fld('name', 'Full name', '<input name="name">') + fld('email', 'VIT email', '<input name="email" type="email" placeholder="name@vitstudent.ac.in">') : ''}
  ${fld('password', 'Password', `<input name="password" type="password" autocomplete="${reg ? 'new' : 'current'}-password">`)}
  <button type="submit">${reg ? 'Sign up' : 'Log in'}</button>
  <p class="mut">${reg ? 'Have an account? <a href="#/login">Log in</a>' : 'New here? <a href="#/register">Sign up</a>'}</p></form>`;
  bindForm(app.querySelector('form'), reg ? 'Sign up' : 'Log in', async d => {
    await api('/api/auth/' + kind, 'POST', d);
    me = (await api('/api/auth/me')).user; renderNav(); location.hash = '#/feed/lost';
  });
}

function route() {
  clearInterval(timer);
  const [, view, arg] = location.hash.split('/');
  ({ feed: () => feed(arg === 'found' ? 'found' : 'lost'), post: postForm, item: () => itemView(+arg), dashboard,
     thread: () => thread(+arg), login: () => authForm('login'), register: () => authForm('register') }[view] || (() => location.hash = '#/feed/lost'))();
}
(async () => {
  try { [meta, me] = [await api('/api/meta'), (await api('/api/auth/me')).user]; }
  catch (e) { return app.innerHTML = `<div class="banner err">${esc(e.message)}</div>`; }
  renderNav(); addEventListener('hashchange', route); route();
})();
