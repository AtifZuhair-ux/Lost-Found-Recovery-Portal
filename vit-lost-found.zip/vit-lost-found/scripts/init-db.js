// Usage: npm run db:init (tables) | npm run db:seed (tables + demo data)
const bcrypt = require('bcryptjs');
const db = require('../db');
console.log('✔ Database schema ready');
if (process.argv.includes('--seed')) {
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c) console.log('Seed skipped: data already exists');
  else {
    const hash = bcrypt.hashSync('password123', 10);
    const u = db.prepare('INSERT INTO users (reg_no,name,email,password_hash) VALUES (?,?,?,?)');
    u.run('25BIT0001', 'Demo Finder', 'finder@vitstudent.ac.in', hash);
    u.run('25BIT0002', 'Demo Claimant', 'claimant@vitstudent.ac.in', hash);
    const i = db.prepare('INSERT INTO items (type,title,description,category,venue,challenge,user_id) VALUES (?,?,?,?,?,?,?)');
    i.run('found', 'Student ID card', 'Found near the stairs, blue lanyard attached.', 'ID Cards', 'SJT', 'What name and branch are printed on the ID?', 1);
    i.run('found', 'Scientific calculator', 'Left on a desk after an exam.', 'Calculators', 'TT', 'What is written on the back cover?', 1);
    i.run('lost', 'Room key with red tag', 'Lost between Gazebo and hostel.', 'Room Keys', 'MH-C', 'Which room number is on the tag you found?', 2);
    console.log('✔ Seeded. Demo logins 25BIT0001 / 25BIT0002, password: password123');
  }
}
