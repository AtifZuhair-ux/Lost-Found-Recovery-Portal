const express = require('express');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const db = require('./db');
const { VENUE_GROUPS, VENUES, CATEGORIES, CHECKPOINTS } = require('./constants');

const SECRET = process.env.JWT_SECRET || 'dev-only-secret';
if (!process.env.JWT_SECRET) console.warn('⚠ JWT_SECRET not set; using insecure dev secret.');

const app = express();
app.use(express.json({ limit: '20kb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- helpers ----------
const fail = (res, code, error, fields) => res.status(code).json({ error, fields });
const str = (v) => (typeof v === 'string' ? v.trim() : '');
const len = (v, min, max) => v.length >= min && v.length <= max;
const wrap = (fn) => (req, res) => { try { fn(req, res); } catch (e) { console.error(e); fail(res, 500, 'Unexpected server error. Please try again.'); } };
const auth = (req, res, next) => {
  try { req.uid = jwt.verify(req.cookies.token, SECRET).id; next(); }
  catch { fail(res, 401, 'Please log in to continue.'); }
};
const optAuth = (req, _res, next) => { try { req.uid = jwt.verify(req.cookies.token, SECRET).id; } catch {} next(); };
const setToken = (res, id) => res.cookie('token', jwt.sign({ id }, SECRET, { expiresIn: '7d' }), { httpOnly: true, sameSite: 'lax', maxAge: 7 * 864e5 });
const role = (item, isPoster) => item.type === 'found' ? (isPoster ? 'Finder' : 'Claimant') : (isPoster ? 'Owner' : 'Finder');
const publicItem = (r) => ({ id: r.id, type: r.type, title: r.title, description: r.description, category: r.category, venue: r.venue, status: r.status, created_at: r.created_at });

const attempts = new Map(); // naive login throttle
const throttled = (ip) => { const a = (attempts.get(ip) || []).filter(t => Date.now() - t < 9e5); attempts.set(ip, a); return a.length >= 10; };

// ---------- meta & auth ----------
app.get('/api/meta', (_req, res) => res.json({ venueGroups: VENUE_GROUPS, categories: CATEGORIES, checkpoints: CHECKPOINTS }));

app.post('/api/auth/register', wrap((req, res) => {
  const reg = str(req.body.reg_no).toUpperCase(), name = str(req.body.name), email = str(req.body.email).toLowerCase(), pw = req.body.password;
  const f = {};
  if (!/^\d{2}[A-Z]{3}\d{4}$/.test(reg)) f.reg_no = 'Use your VIT registration number, e.g. 25BIT0123.';
  if (!len(name, 2, 60)) f.name = 'Name must be 2–60 characters.';
  if (!/^[^@\s]+@vitstudent\.ac\.in$/.test(email)) f.email = 'Use your @vitstudent.ac.in email.';
  if (typeof pw !== 'string' || pw.length < 8 || pw.length > 72) f.password = 'Password must be 8–72 characters.';
  if (Object.keys(f).length) return fail(res, 400, 'Please fix the highlighted fields.', f);
  try {
    const r = db.prepare('INSERT INTO users (reg_no,name,email,password_hash) VALUES (?,?,?,?)').run(reg, name, email, bcrypt.hashSync(pw, 10));
    setToken(res, r.lastInsertRowid);
    res.status(201).json({ id: r.lastInsertRowid, name });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return fail(res, 409, 'An account with this registration number or email already exists.');
    throw e;
  }
}));

app.post('/api/auth/login', wrap((req, res) => {
  if (throttled(req.ip)) return fail(res, 429, 'Too many attempts. Try again in a few minutes.');
  const u = db.prepare('SELECT * FROM users WHERE reg_no = ?').get(str(req.body.reg_no).toUpperCase());
  if (!u || typeof req.body.password !== 'string' || !bcrypt.compareSync(req.body.password, u.password_hash)) {
    attempts.get(req.ip).push(Date.now());
    return fail(res, 401, 'Invalid registration number or password.');
  }
  setToken(res, u.id);
  res.json({ id: u.id, name: u.name });
}));

app.post('/api/auth/logout', (_req, res) => res.clearCookie('token').json({ ok: true }));
app.get('/api/auth/me', optAuth, wrap((req, res) => {
  const u = req.uid && db.prepare('SELECT id,name FROM users WHERE id=?').get(req.uid);
  res.json({ user: u || null });
}));

// ---------- items (public view never exposes poster identity) ----------
app.get('/api/items', wrap((req, res) => {
  const type = req.query.type === 'found' ? 'found' : 'lost';
  let sql = "SELECT * FROM items WHERE status='active' AND type=?"; const p = [type];
  if (CATEGORIES.includes(req.query.category)) { sql += ' AND category=?'; p.push(req.query.category); }
  if (VENUES.includes(req.query.venue)) { sql += ' AND venue=?'; p.push(req.query.venue); }
  const q = str(req.query.q).slice(0, 60);
  if (q) { sql += ' AND (title LIKE ? OR description LIKE ?)'; p.push(`%${q}%`, `%${q}%`); }
  res.json(db.prepare(sql + ' ORDER BY id DESC LIMIT 100').all(...p).map(publicItem));
}));

app.post('/api/items', auth, wrap((req, res) => {
  const b = req.body, type = b.type, title = str(b.title), description = str(b.description), challenge = str(b.challenge);
  const f = {};
  if (!['lost', 'found'].includes(type)) f.type = 'Choose Lost or Found.';
  if (!len(title, 3, 80)) f.title = 'Title must be 3–80 characters.';
  if (!len(description, 10, 500)) f.description = 'Description must be 10–500 characters.';
  if (!CATEGORIES.includes(b.category)) f.category = 'Pick a valid category.';
  if (!VENUES.includes(b.venue)) f.venue = 'Pick an official VIT campus location.';
  if (!len(challenge, 5, 200)) f.challenge = 'Verification question must be 5–200 characters.';
  if (Object.keys(f).length) return fail(res, 400, 'Please fix the highlighted fields.', f);
  const r = db.prepare('INSERT INTO items (type,title,description,category,venue,challenge,user_id) VALUES (?,?,?,?,?,?,?)')
    .run(type, title, description, b.category, b.venue, challenge, req.uid);
  res.status(201).json({ id: r.lastInsertRowid });
}));

app.get('/api/items/:id', optAuth, wrap((req, res) => {
  const it = db.prepare('SELECT * FROM items WHERE id=?').get(+req.params.id);
  if (!it) return fail(res, 404, 'Listing not found.');
  const isPoster = req.uid === it.user_id;
  const mine = req.uid && !isPoster ? db.prepare('SELECT id,status FROM claims WHERE item_id=? AND claimant_id=?').get(it.id, req.uid) : null;
  res.json({ ...publicItem(it), challenge: it.challenge, isPoster, myClaim: mine || null, postedBy: `Anonymous ${role(it, true)}` });
}));

const canResolve = (it, uid) => it.user_id === uid ||
  !!db.prepare("SELECT 1 FROM claims WHERE item_id=? AND claimant_id=? AND status='approved'").get(it.id, uid);
app.post('/api/items/:id/resolve', auth, wrap((req, res) => {
  const it = db.prepare('SELECT * FROM items WHERE id=?').get(+req.params.id);
  if (!it) return fail(res, 404, 'Listing not found.');
  if (!canResolve(it, req.uid)) return fail(res, 403, 'Only the poster or an approved party can resolve this.');
  db.prepare("UPDATE items SET status='resolved', resolved_at=CURRENT_TIMESTAMP WHERE id=?").run(it.id);
  res.json({ ok: true });
}));

// ---------- claims ----------
app.post('/api/items/:id/claims', auth, wrap((req, res) => {
  const it = db.prepare('SELECT * FROM items WHERE id=?').get(+req.params.id);
  if (!it || it.status !== 'active') return fail(res, 404, 'This listing is no longer active.');
  if (it.user_id === req.uid) return fail(res, 403, 'You cannot claim your own listing.');
  const answer = str(req.body.answer);
  if (!len(answer, 3, 300)) return fail(res, 400, 'Please fix the highlighted fields.', { answer: 'Answer must be 3–300 characters.' });
  try {
    const r = db.prepare('INSERT INTO claims (item_id,claimant_id,answer) VALUES (?,?,?)').run(it.id, req.uid, answer);
    res.status(201).json({ id: r.lastInsertRowid });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return fail(res, 409, 'You already submitted a request for this listing.');
    throw e;
  }
}));

app.get('/api/dashboard', auth, wrap((req, res) => {
  const listings = db.prepare('SELECT * FROM items WHERE user_id=? ORDER BY id DESC').all(req.uid).map(it => ({
    ...publicItem(it), challenge: it.challenge,
    claims: db.prepare('SELECT id,answer,status,created_at FROM claims WHERE item_id=? ORDER BY id DESC').all(it.id)
      .map(c => ({ ...c, alias: `Anonymous ${role(it, false)} #${c.id}` }))
  }));
  const myClaims = db.prepare(`SELECT c.id claim_id, c.status claim_status, c.created_at, i.id, i.type, i.title, i.venue, i.status
    FROM claims c JOIN items i ON i.id=c.item_id WHERE c.claimant_id=? ORDER BY c.id DESC`).all(req.uid);
  res.json({ listings, myClaims });
}));

app.post('/api/claims/:id/decision', auth, wrap((req, res) => {
  const c = db.prepare('SELECT c.*, i.user_id poster, i.status istatus FROM claims c JOIN items i ON i.id=c.item_id WHERE c.id=?').get(+req.params.id);
  if (!c || c.poster !== req.uid) return fail(res, 404, 'Claim not found.');
  if (!['approved', 'rejected'].includes(req.body.decision)) return fail(res, 400, 'Decision must be approved or rejected.');
  if (c.istatus !== 'active') return fail(res, 409, 'This listing is already resolved.');
  if (c.status !== 'pending') return fail(res, 409, 'This claim has already been decided.');
  db.prepare('UPDATE claims SET status=? WHERE id=?').run(req.body.decision, c.id);
  if (req.body.decision === 'approved')
    db.prepare('INSERT INTO messages (claim_id,sender_id,body) VALUES (?,NULL,?)').run(c.id, 'Claim approved. Agree on a campus meetup checkpoint here. Do not share personal contact details unless you are comfortable doing so.');
  res.json({ ok: true });
}));

// ---------- handoff thread (only the two parties, only once approved) ----------
function loadThread(req, res) {
  const c = db.prepare('SELECT c.*, i.user_id poster, i.type, i.title, i.status istatus, i.id item_id FROM claims c JOIN items i ON i.id=c.item_id WHERE c.id=?').get(+req.params.id);
  if (!c || (c.poster !== req.uid && c.claimant_id !== req.uid)) return fail(res, 404, 'Conversation not found.'), null;
  if (c.status !== 'approved') return fail(res, 403, 'Chat opens once the claim is approved.'), null;
  return c;
}
app.get('/api/claims/:id/thread', auth, wrap((req, res) => {
  const c = loadThread(req, res); if (!c) return;
  const msgs = db.prepare('SELECT sender_id,body,created_at FROM messages WHERE claim_id=? ORDER BY id').all(c.id).map(m => ({
    system: m.sender_id === null, mine: m.sender_id === req.uid,
    from: m.sender_id === null ? 'System' : role(c, m.sender_id === c.poster), body: m.body, created_at: m.created_at
  }));
  res.json({ claimId: c.id, itemId: c.item_id, title: c.title, resolved: c.istatus === 'resolved', checkpoint: c.checkpoint, messages: msgs });
}));
app.post('/api/claims/:id/messages', auth, wrap((req, res) => {
  const c = loadThread(req, res); if (!c) return;
  if (c.istatus === 'resolved') return fail(res, 409, 'This item is resolved; the chat is closed.');
  const body = str(req.body.body);
  if (!len(body, 1, 500)) return fail(res, 400, 'Message must be 1–500 characters.');
  db.prepare('INSERT INTO messages (claim_id,sender_id,body) VALUES (?,?,?)').run(c.id, req.uid, body);
  res.status(201).json({ ok: true });
}));
app.post('/api/claims/:id/checkpoint', auth, wrap((req, res) => {
  const c = loadThread(req, res); if (!c) return;
  if (c.istatus === 'resolved') return fail(res, 409, 'This item is resolved.');
  if (!CHECKPOINTS.includes(req.body.checkpoint)) return fail(res, 400, 'Choose a listed campus checkpoint.');
  db.prepare('UPDATE claims SET checkpoint=? WHERE id=?').run(req.body.checkpoint, c.id);
  db.prepare('INSERT INTO messages (claim_id,sender_id,body) VALUES (?,NULL,?)').run(c.id, `📍 ${role(c, req.uid === c.poster)} proposed meetup: ${req.body.checkpoint}`);
  res.json({ ok: true });
}));

app.use('/api', (_req, res) => fail(res, 404, 'Unknown API route.'));
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`VIT Lost & Found running on http://localhost:${PORT}`));
